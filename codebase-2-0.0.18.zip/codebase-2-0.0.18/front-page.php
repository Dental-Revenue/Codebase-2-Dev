<?php
	
get_header();

get_partial('/partials/module_loop');

get_footer();


?>