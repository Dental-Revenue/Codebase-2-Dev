<?php
	
	$box->add_field( array(
		'name' => 'Title',
		'id' => $prefix.'title',
		'type' => 'text',
		'default' => 'Patient Testimonials'
	));
				
?>