<?php
	
	$box->add_field( array(
		'name' => 'Headline',
		'id' => $prefix.'headline',
		'description' => 'Supports {bold}',
		'type' => 'text'
	));

?>